/*
 * =========================================================
 * MOODMENT STATIC PUBLIC TRANSPORT DATA
 * =========================================================
 *
 * This data is NOT real-time.
 *
 * It is used to provide general public transport
 * information around calculated meeting points.
 *
 * Coordinates are approximate station coordinates.
 *
 * =========================================================
 */

const transportData = {

  /*
   * =======================================================
   * RAILWAY STATIONS
   * =======================================================
   */

  railway: [

    {
      name: "Vashi Railway Station",
      type: "Railway Station",
      lat: 19.0671,
      lng: 72.9975,
      area: "Vashi",
      city: "Navi Mumbai",
      operator: "Central Railway",
      lines: [
        "Harbour Line"
      ]
    },

    {
      name: "Sanpada Railway Station",
      type: "Railway Station",
      lat: 19.0687,
      lng: 73.0098,
      area: "Sanpada",
      city: "Navi Mumbai",
      operator: "Central Railway",
      lines: [
        "Harbour Line"
      ]
    },

    {
      name: "Juinagar Railway Station",
      type: "Railway Station",
      lat: 19.0544,
      lng: 73.0180,
      area: "Juinagar",
      city: "Navi Mumbai",
      operator: "Central Railway",
      lines: [
        "Harbour Line"
      ]
    },

    {
      name: "Nerul Railway Station",
      type: "Railway Station",
      lat: 19.0330,
      lng: 73.0183,
      area: "Nerul",
      city: "Navi Mumbai",
      operator: "Central Railway",
      lines: [
        "Harbour Line"
      ]
    },

    {
      name: "Seawoods-Darave Railway Station",
      type: "Railway Station",
      lat: 19.0195,
      lng: 73.0150,
      area: "Seawoods",
      city: "Navi Mumbai",
      operator: "Central Railway",
      lines: [
        "Harbour Line"
      ]
    },

    {
      name: "Belapur CBD Railway Station",
      type: "Railway Station",
      lat: 19.0168,
      lng: 73.0390,
      area: "CBD Belapur",
      city: "Navi Mumbai",
      operator: "Central Railway",
      lines: [
        "Harbour Line"
      ]
    },

    {
      name: "Kharghar Railway Station",
      type: "Railway Station",
      lat: 19.0473,
      lng: 73.0699,
      area: "Kharghar",
      city: "Navi Mumbai",
      operator: "Central Railway",
      lines: [
        "Harbour Line"
      ]
    },

    {
      name: "Mansarovar Railway Station",
      type: "Railway Station",
      lat: 19.0160,
      lng: 73.0800,
      area: "Mansarovar",
      city: "Navi Mumbai",
      operator: "Central Railway",
      lines: [
        "Harbour Line"
      ]
    },

    {
      name: "Khandeshwar Railway Station",
      type: "Railway Station",
      lat: 19.0065,
      lng: 73.0808,
      area: "Khandeshwar",
      city: "Navi Mumbai",
      operator: "Central Railway",
      lines: [
        "Harbour Line"
      ]
    },

    {
      name: "Panvel Railway Station",
      type: "Railway Station",
      lat: 18.9894,
      lng: 73.1175,
      area: "Panvel",
      city: "Navi Mumbai",
      operator: "Central Railway",
      lines: [
        "Harbour Line",
        "Trans-Harbour connectivity"
      ]
    }

  ],


  /*
   * =======================================================
   * METRO STATIONS
   * =======================================================
   */

  metro: [

    {
      name: "Belapur Metro Station",
      type: "Metro Station",
      lat: 19.0178,
      lng: 73.0417,
      area: "CBD Belapur",
      city: "Navi Mumbai",
      line: "Navi Mumbai Metro Line 1"
    },

    {
      name: "Belpada Metro Station",
      type: "Metro Station",
      lat: 19.0335,
      lng: 73.0615,
      area: "Belpada",
      city: "Navi Mumbai",
      line: "Navi Mumbai Metro Line 1"
    },

    {
      name: "Kharghar Village Metro Station",
      type: "Metro Station",
      lat: 19.0448,
      lng: 73.0605,
      area: "Kharghar",
      city: "Navi Mumbai",
      line: "Navi Mumbai Metro Line 1"
    },

    {
      name: "Central Park Metro Station",
      type: "Metro Station",
      lat: 19.0455,
      lng: 73.0680,
      area: "Kharghar",
      city: "Navi Mumbai",
      line: "Navi Mumbai Metro Line 1"
    },

    {
      name: "Pethpada Metro Station",
      type: "Metro Station",
      lat: 19.0570,
      lng: 73.0730,
      area: "Kharghar",
      city: "Navi Mumbai",
      line: "Navi Mumbai Metro Line 1"
    },

    {
      name: "Kharghar Metro Station",
      type: "Metro Station",
      lat: 19.0630,
      lng: 73.0780,
      area: "Kharghar",
      city: "Navi Mumbai",
      line: "Navi Mumbai Metro Line 1"
    }

  ],


  /*
   * =======================================================
   * BUS SERVICES
   * =======================================================
   *
   * Bus data is service-level information rather than
   * individual bus stops.
   *
   * =======================================================
   */

  bus: [

    {
      name: "NMMT",
      type: "Bus Service",
      operator: "Navi Mumbai Municipal Transport",
      areas: [
        "Vashi",
        "Sanpada",
        "Nerul",
        "Seawoods",
        "Belapur",
        "Kharghar",
        "Panvel"
      ],
      description:
        "Navi Mumbai Municipal Transport buses provide connectivity across Navi Mumbai and nearby areas."
    },

    {
      name: "BEST",
      type: "Bus Service",
      operator: "Brihanmumbai Electric Supply and Transport",
      areas: [
        "Vashi",
        "Navi Mumbai",
        "Mumbai"
      ],
      description:
        "BEST buses provide connectivity between Mumbai and selected Navi Mumbai areas."
    },

    {
      name: "MSRTC",
      type: "Bus Service",
      operator: "Maharashtra State Road Transport Corporation",
      areas: [
        "Panvel",
        "Navi Mumbai",
        "Thane",
        "Mumbai"
      ],
      description:
        "MSRTC buses provide intercity and regional connectivity across Maharashtra."
    }

  ]

};


/*
 * =========================================================
 * EXPORT
 * =========================================================
 */

module.exports = transportData;