const express = require("express");

const router = express.Router();

/*
 * =========================================================
 * TRAVEL ROUTES
 * =========================================================
 *
 * Handles:
 * 1. Geocoding
 * 2. Reverse geocoding
 * 3. Geographic midpoint calculation
 *
 * =========================================================
 */

/*
 * =========================================================
 * NOMINATIM CONFIGURATION
 * =========================================================
 */

const NOMINATIM_URL =
  "https://nominatim.openstreetmap.org";

/*
 * =========================================================
 * NOMINATIM HEADERS
 * =========================================================
 */

const nominatimHeaders = {
  "User-Agent":
    "MoodMate/1.0 (moodmate-location-app)",

  Accept:
    "application/json",

  "Accept-Language":
    "en",
};

/*
 * =========================================================
 * SIMPLE CACHE
 * =========================================================
 *
 * Prevents repeatedly asking Nominatim for the same place.
 * This is especially useful during development because
 * React StrictMode can cause requests more than once.
 * =========================================================
 */

const geocodeCache = new Map();

const reverseGeocodeCache = new Map();

/*
 * =========================================================
 * REQUEST DELAY
 * =========================================================
 *
 * Nominatim has rate limits.
 * Keep requests spaced apart.
 * =========================================================
 */

let lastNominatimRequest = 0;

const waitForNominatim = async () => {
  const now = Date.now();

  const elapsed =
    now - lastNominatimRequest;

  const minimumDelay = 1100;

  if (elapsed < minimumDelay) {
    await new Promise((resolve) => {
      setTimeout(
        resolve,
        minimumDelay - elapsed
      );
    });
  }

  lastNominatimRequest = Date.now();
};

/*
 * =========================================================
 * GEOCODE PLACE
 * =========================================================
 */

const geocodePlace = async (place) => {

  if (
    !place ||
    typeof place !== "string" ||
    !place.trim()
  ) {
    return null;
  }

  const cleanPlace =
    place.trim();

  const cacheKey =
    cleanPlace.toLowerCase();

  /*
   * Return cached result
   */

  if (geocodeCache.has(cacheKey)) {
    console.log(
      "Using cached geocode:",
      cleanPlace
    );

    return geocodeCache.get(cacheKey);
  }

  /*
   * Wait before contacting Nominatim
   */

  await waitForNominatim();

  const query =
    encodeURIComponent(
      cleanPlace
    );

  const url =
    `${NOMINATIM_URL}/search` +
    `?format=jsonv2` +
    `&q=${query}` +
    `&limit=1` +
    `&addressdetails=1`;

  console.log(
    "Nominatim geocoding:",
    cleanPlace
  );

  const response =
    await fetch(
      url,
      {
        method: "GET",
        headers: nominatimHeaders,
      }
    );

  if (!response.ok) {

    throw new Error(
      `Geocoding service returned ${response.status}.`
    );
  }

  const data =
    await response.json();

  if (
    !Array.isArray(data) ||
    data.length === 0
  ) {
    return null;
  }

  const result =
    data[0];

  const lat =
    Number(result.lat);

  const lng =
    Number(result.lon);

  if (
    !Number.isFinite(lat) ||
    !Number.isFinite(lng)
  ) {
    return null;
  }

  const finalResult = {

    lat,

    lng,

    displayName:
      result.display_name ||
      cleanPlace,

    address:
      result.address ||
      {},
  };

  /*
   * Save in cache
   */

  geocodeCache.set(
    cacheKey,
    finalResult
  );

  return finalResult;
};

/*
 * =========================================================
 * REVERSE GEOCODE
 * =========================================================
 *
 * IMPORTANT:
 *
 * Reverse geocoding is OPTIONAL.
 *
 * If Nominatim returns 429 or another error,
 * we return null instead of breaking the midpoint.
 *
 * =========================================================
 */

const reverseGeocodePlace =
  async (lat, lng) => {

    const cacheKey =
      `${Number(lat).toFixed(5)},${Number(lng).toFixed(5)}`;

    /*
     * Check cache
     */

    if (
      reverseGeocodeCache.has(
        cacheKey
      )
    ) {

      console.log(
        "Using cached reverse geocode:",
        cacheKey
      );

      return reverseGeocodeCache.get(
        cacheKey
      );
    }

    try {

      await waitForNominatim();

      const url =
        `${NOMINATIM_URL}/reverse` +
        `?format=jsonv2` +
        `&lat=${encodeURIComponent(lat)}` +
        `&lon=${encodeURIComponent(lng)}` +
        `&zoom=18` +
        `&addressdetails=1`;

      console.log(
        "Nominatim reverse geocoding:",
        lat,
        lng
      );

      const response =
        await fetch(
          url,
          {
            method: "GET",
            headers: nominatimHeaders,
          }
        );

      /*
       * IMPORTANT:
       * Do NOT throw on 429.
       */

      if (!response.ok) {

        console.warn(
          `Reverse geocoding skipped. Nominatim returned ${response.status}.`
        );

        return null;
      }

      const data =
        await response.json();

      if (
        !data ||
        !data.display_name
      ) {

        return null;
      }

      const result = {

        displayName:
          data.display_name,

        address:
          data.address ||
          {},
      };

      reverseGeocodeCache.set(
        cacheKey,
        result
      );

      return result;

    } catch (error) {

      /*
       * Reverse geocoding should NEVER
       * stop the midpoint calculation.
       */

      console.warn(
        "Reverse geocoding skipped:",
        error.message
      );

      return null;
    }
  };

/*
 * =========================================================
 * HAVERSINE DISTANCE
 * =========================================================
 */

const calculateDistance = (
  lat1,
  lng1,
  lat2,
  lng2
) => {

  const R = 6371;

  const dLat =
    ((lat2 - lat1) *
      Math.PI) /
    180;

  const dLng =
    ((lng2 - lng1) *
      Math.PI) /
    180;

  const a =
    Math.sin(dLat / 2) *
      Math.sin(dLat / 2) +

    Math.cos(
      (lat1 * Math.PI) /
        180
    ) *

      Math.cos(
        (lat2 * Math.PI) /
          180
      ) *

      Math.sin(dLng / 2) *
      Math.sin(dLng / 2);

  const c =
    2 *
    Math.atan2(
      Math.sqrt(a),
      Math.sqrt(1 - a)
    );

  return R * c;
};

/*
 * =========================================================
 * CALCULATE GEOGRAPHIC CENTER
 * =========================================================
 */

const calculateCenter =
  (locations) => {

    if (
      !Array.isArray(locations) ||
      locations.length === 0
    ) {

      return null;
    }

    let x = 0;
    let y = 0;
    let z = 0;

    locations.forEach(
      (location) => {

        const lat =
          Number(
            location.lat
          );

        const lng =
          Number(
            location.lng
          );

        const latitude =
          (lat * Math.PI) /
          180;

        const longitude =
          (lng * Math.PI) /
          180;

        x +=
          Math.cos(latitude) *
          Math.cos(longitude);

        y +=
          Math.cos(latitude) *
          Math.sin(longitude);

        z +=
          Math.sin(latitude);
      }
    );

    x /=
      locations.length;

    y /=
      locations.length;

    z /=
      locations.length;

    const longitude =
      Math.atan2(
        y,
        x
      );

    const hyp =
      Math.sqrt(
        x * x +
        y * y
      );

    const latitude =
      Math.atan2(
        z,
        hyp
      );

    return {

      lat:
        (latitude * 180) /
        Math.PI,

      lng:
        (longitude * 180) /
        Math.PI,
    };
  };

/*
 * =========================================================
 * VALIDATE COORDINATE
 * =========================================================
 */

const isValidCoordinate =
  (location) => {

    if (!location) {
      return false;
    }

    const lat =
      Number(
        location.lat
      );

    const lng =
      Number(
        location.lng
      );

    return (

      Number.isFinite(lat) &&

      Number.isFinite(lng) &&

      lat >= -90 &&

      lat <= 90 &&

      lng >= -180 &&

      lng <= 180
    );
  };

/*
 * =========================================================
 * GEOCODE API
 * =========================================================
 */

router.get(
  "/geocode",
  async (req, res) => {

    try {

      const place =
        String(
          req.query.place || ""
        ).trim();

      if (!place) {

        return res.status(400).json({

          success: false,

          message:
            "Please provide a location.",
        });
      }

      console.log(
        "Geocoding location:",
        place
      );

      const result =
        await geocodePlace(
          place
        );

      if (!result) {

        return res.status(404).json({

          success: false,

          message:
            `Location "${place}" could not be found.`,
        });
      }

      return res.json({

        success: true,

        lat:
          result.lat,

        lng:
          result.lng,

        displayName:
          result.displayName,

        address:
          result.address,
      });

    } catch (error) {

      console.error(
        "Geocode error:",
        error.message
      );

      return res.status(500).json({

        success: false,

        message:
          error.message ||
          "Unable to geocode location.",
      });
    }
  }
);

/*
 * =========================================================
 * REVERSE GEOCODE API
 * =========================================================
 */

router.get(
  "/reverse-geocode",
  async (req, res) => {

    try {

      const lat =
        Number(
          req.query.lat
        );

      const lng =
        Number(
          req.query.lng
        );

      if (
        !Number.isFinite(lat) ||
        !Number.isFinite(lng) ||
        lat < -90 ||
        lat > 90 ||
        lng < -180 ||
        lng > 180
      ) {

        return res.status(400).json({

          success: false,

          message:
            "Invalid coordinates.",
        });
      }

      const result =
        await reverseGeocodePlace(
          lat,
          lng
        );

      /*
       * Reverse geocoding failure is NOT
       * considered a midpoint failure.
       */

      if (!result) {

        return res.json({

          success: false,

          displayName:
            "Smart Meeting Point",

          address: {},
        });
      }

      return res.json({

        success: true,

        displayName:
          result.displayName,

        address:
          result.address,
      });

    } catch (error) {

      /*
       * This should almost never be reached
       * because reverseGeocodePlace already
       * handles its own errors.
       */

      console.warn(
        "Reverse geocode skipped:",
        error.message
      );

      return res.json({

        success: false,

        displayName:
          "Smart Meeting Point",

        address: {},
      });
    }
  }
);

/*
 * =========================================================
 * CALCULATE MEETING POINT
 * =========================================================
 */

router.post(
  "/calculate",
  async (req, res) => {

    try {

      const {
        locations,
        travelMode = "private",
      } = req.body;

      /*
       * VALIDATE LOCATIONS
       */

      if (
        !Array.isArray(
          locations
        ) ||
        locations.length === 0
      ) {

        return res.status(400).json({

          success: false,

          message:
            "No locations were provided.",
        });
      }

      /*
       * VALID COORDINATES
       */

      const validLocations =
        locations
          .filter(
            isValidCoordinate
          )
          .map(
            (location) => ({

              ...location,

              lat:
                Number(
                  location.lat
                ),

              lng:
                Number(
                  location.lng
                ),
            })
          );

      if (
        validLocations.length === 0
      ) {

        return res.status(400).json({

          success: false,

          message:
            "No valid coordinates were provided.",
        });
      }

      /*
       * CALCULATE MIDPOINT
       */

      const center =
        calculateCenter(
          validLocations
        );

      if (!center) {

        return res.status(500).json({

          success: false,

          message:
            "Unable to calculate meeting point.",
        });
      }

      /*
       * CALCULATE DISTANCES
       */

      const distances =
        validLocations.map(
          (location) => ({

            name:
              location.name ||
              "Group Member",

            location:
              location.location ||
              location.displayName ||
              "",

            distanceFromMidpoint:
              Number(
                calculateDistance(
                  center.lat,
                  center.lng,
                  location.lat,
                  location.lng
                ).toFixed(2)
              ),
          })
        );

      console.log(
        "Calculated meeting point:",
        center
      );

      /*
       * IMPORTANT
       *
       * We DO NOT call reverse geocoding here.
       *
       * This prevents the 429 problem from
       * affecting the midpoint calculation.
       */

      const midpoint = {

        lat:
          center.lat,

        lng:
          center.lng,

        name:
          "Smart Meeting Point",
      };

      /*
       * RESPONSE
       */

      return res.json({

        success: true,

        meetingPoint: {

          lat:
            center.lat,

          lng:
            center.lng,

          name:
            "Smart Meeting Point",

          type:
            travelMode === "public"
              ? "Public Transport"
              : "Private Vehicle",
        },

        midpoint,

        travelMode,

        description:
          travelMode === "public"

            ? "A central meeting point was calculated from the group's locations. Public transport information will be added around this exact midpoint."

            : "A central meeting point was calculated from the group's locations.",

        method:
          "geographic-center",

        distances,

        locations:
          validLocations,
      });

    } catch (error) {

      console.error(
        "Travel calculation error:",
        error
      );

      return res.status(500).json({

        success: false,

        message:
          error.message ||
          "Unable to calculate meeting point.",
      });
    }
  }
);

/*
 * =========================================================
 * TEST ROUTE
 * =========================================================
 */

router.get(
  "/test",
  (req, res) => {

    res.json({

      success: true,

      message:
        "Travel API is working.",

      endpoints: {

        geocode:
          "/api/travel/geocode?place=Dadar",

        reverseGeocode:
          "/api/travel/reverse-geocode?lat=19.0192269&lng=72.8428479",

        calculate:
          "/api/travel/calculate",
      },
    });
  }
);

/*
 * =========================================================
 * EXPORT
 * =========================================================
 */

module.exports =
  router;