const express = require("express");
const cors = require("cors");

const travelRoutes = require("./routes/travel");

const app = express();

const PORT = 5000;

/*
 * =========================================================
 * MIDDLEWARE
 * =========================================================
 */

app.use(cors());

app.use(express.json());


/*
 * =========================================================
 * HOME / SERVER TEST
 * =========================================================
 */

app.get("/", (req, res) => {
  res.json({
    success: true,
    message: "MoodMate server is running",
  });
});


/*
 * =========================================================
 * TRAVEL ROUTES
 * =========================================================
 *
 * Includes:
 *
 * GET  /api/travel/geocode
 * GET  /api/travel/reverse-geocode
 * POST /api/travel/calculate
 *
 * =========================================================
 */

app.use(
  "/api/travel",
  travelRoutes
);


/*
 * =========================================================
 * START SERVER
 * =========================================================
 */

app.listen(PORT, () => {
  console.log(
    `MoodMate server running on http://localhost:${PORT}`
  );
});