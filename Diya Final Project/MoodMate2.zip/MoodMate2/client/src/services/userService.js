import { doc, setDoc, serverTimestamp } from "firebase/firestore";
import { db } from "./firebase";

export const createUserDocument = async (user, name) => {
  await setDoc(doc(db, "users", user.uid), {
    name: name,
    email: user.email,
    createdAt: serverTimestamp(),
  });
};