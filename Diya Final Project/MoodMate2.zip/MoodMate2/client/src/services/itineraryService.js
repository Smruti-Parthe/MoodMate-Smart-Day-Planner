// ============================================================
// MOODMATE ITINERARY MAPPING
// ============================================================
//
// Each main place/activity suggests what the group can do next.
//
// Example:
// cafe
// → dessert
// → park
// → bookstore
// → shopping
//
// This file only contains the ITINERARY LOGIC.
// Actual places will be searched later using OpenStreetMap.
// ============================================================

export const itineraryMapping = {
  cafe: [
    "dessert",
    "park",
    "bookstore",
    "shopping",
  ],

  restaurant: [
    "dessert",
    "movie_theater",
    "mall",
    "cafe",
  ],

  movie_theater: [
    "restaurant",
    "dessert",
    "gaming_zone",
  ],

  mall: [
    "restaurant",
    "gaming_zone",
    "movie_theater",
    "cafe",
  ],

  park: [
    "cafe",
    "ice_cream",
    "lake",
  ],

  temple: [
    "park",
    "cafe",
    "lake",
  ],

  beach: [
    "cafe",
    "dessert",
    "shopping",
  ],

  escape_room: [
    "restaurant",
    "gaming_zone",
    "dessert",
  ],

  adventure_park: [
    "restaurant",
    "cafe",
    "shopping",
  ],

  gaming_zone: [
    "restaurant",
    "movie_theater",
    "dessert",
  ],

  rooftop_restaurant: [
    "dessert",
    "garden",
    "viewpoint",
  ],
};

// ============================================================
// FALLBACK ACTIVITIES
// ============================================================
//
// If a recommended place does not exist in the mapping above,
// these activities will be used as possible next stops.
// ============================================================

const defaultItinerary = [
  "cafe",
  "restaurant",
  "dessert",
];

// ============================================================
// NORMALIZE CATEGORY
// ============================================================
//
// Converts different category names into a consistent format.
//
// Example:
// "Café" → "cafe"
// "Movie Theater" → "movie_theater"
// "RoofTop Restaurant" → "rooftop_restaurant"
// ============================================================

export const normalizeCategory = (category) => {
  if (!category) {
    return "";
  }

  return category
    .toString()
    .trim()
    .toLowerCase()
    .replace(/&/g, "and")
    .replace(/\s+/g, "_")
    .replace(/-/g, "_");
};

// ============================================================
// GET NEXT ACTIVITIES
// ============================================================
//
// Input:
//     category = main recommended place
//
// Output:
//     Array of suggested next activities
//
// Example:
// getNextActivities("cafe")
//
// returns:
// ["dessert", "park", "bookstore", "shopping"]
// ============================================================

export const getNextActivities = (category) => {
  const normalizedCategory =
    normalizeCategory(category);

  return (
    itineraryMapping[normalizedCategory] ||
    defaultItinerary
  );
};

// ============================================================
// GET ITINERARY ACTIVITIES
// ============================================================
//
// Creates the complete activity sequence.
//
// The first activity is the selected/recommended place.
// Then activities are taken from itineraryMapping.
//
// Example:
//
// getItineraryActivities("cafe", 4)
//
// returns:
//
// [
//   "cafe",
//   "dessert",
//   "park",
//   "bookstore"
// ]
//
// count controls how many total activities
// should appear in the itinerary.
// ============================================================

export const getItineraryActivities = (
  category,
  count = 4
) => {
  const normalizedCategory =
    normalizeCategory(category);

  const nextActivities =
    getNextActivities(normalizedCategory);

  const activities = [
    normalizedCategory,
    ...nextActivities,
  ];

  // Remove duplicates
  const uniqueActivities = [
    ...new Set(activities),
  ];

  return uniqueActivities.slice(0, count);
};

// ============================================================
// GET FULL ITINERARY
// ============================================================
//
// Returns objects instead of only category strings.
//
// Example:
//
// getItinerary("cafe")
//
// returns:
//
// [
//   {
//     step: 1,
//     category: "cafe"
//   },
//   {
//     step: 2,
//     category: "dessert"
//   },
//   ...
// ]
//
// This structure will be useful later when we connect
// actual OpenStreetMap places.
// ============================================================

export const getItinerary = (
  category,
  count = 4
) => {
  const activities =
    getItineraryActivities(
      category,
      count
    );

  return activities.map(
    (activity, index) => ({
      step: index + 1,
      category: activity,
    })
  );
};

// ============================================================
// ACTIVITY DISPLAY NAMES
// ============================================================
//
// Converts technical category names into user-friendly names.
// ============================================================

export const itineraryDisplayNames = {
  cafe: "Café",

  restaurant: "Restaurant",

  movie_theater: "Movie Theater",

  mall: "Mall",

  park: "Park",

  temple: "Temple",

  beach: "Beach",

  escape_room: "Escape Room",

  adventure_park: "Adventure Park",

  gaming_zone: "Gaming Zone",

  dessert: "Dessert",

  bookstore: "Bookstore",

  shopping: "Shopping",

  ice_cream: "Ice Cream",

  lake: "Lake",

  garden: "Garden",

  viewpoint: "Viewpoint",
};

// ============================================================
// GET DISPLAY NAME
// ============================================================

export const getItineraryDisplayName = (
  category
) => {
  const normalizedCategory =
    normalizeCategory(category);

  return (
    itineraryDisplayNames[
      normalizedCategory
    ] ||
    normalizedCategory
      .replace(/_/g, " ")
      .replace(/\b\w/g, (letter) =>
        letter.toUpperCase()
      )
  );
};