import {
  collection,
  addDoc,
  serverTimestamp,
} from "firebase/firestore";

import { db } from "./firebase";

/*
==================================================
SAVE COMPLETE PLAN
==================================================

A plan is saved inside:

users
  └── USER_UID
       └── plans
            └── PLAN_ID
*/

export const savePlan = async (user, planData) => {
  if (!user || !user.uid) {
    throw new Error("User is not logged in.");
  }

  if (!planData) {
    throw new Error("No plan data provided.");
  }

  /*
  ------------------------------------------------
  CLEAN MEMBERS
  ------------------------------------------------
  */

  const members = Array.isArray(planData.members)
    ? planData.members.map((member) => ({
        name: member?.name || "",
        location: member?.location || "",
        lat:
          member?.lat != null
            ? Number(member.lat)
            : null,
        lng:
          member?.lng != null
            ? Number(member.lng)
            : null,
      }))
    : [];

  /*
  ------------------------------------------------
  CLEAN MIDPOINT
  ------------------------------------------------
  */

  const midpoint = planData.midpoint
    ? {
        name: planData.midpoint.name || "",
        lat:
          planData.midpoint.lat != null
            ? Number(planData.midpoint.lat)
            : null,
        lng:
          planData.midpoint.lng != null
            ? Number(planData.midpoint.lng)
            : null,
      }
    : null;

  /*
  ------------------------------------------------
  CLEAN RECOMMENDED PLACES
  ------------------------------------------------
  */

  const places = Array.isArray(planData.places)
    ? planData.places.map((place) => ({
        id: place?.id || "",
        name: place?.name || "",
        address: place?.address || "",
        category: place?.category || "",
        distance:
          place?.distance != null
            ? Number(place.distance)
            : null,
        lat:
          place?.lat != null
            ? Number(place.lat)
            : null,
        lng:
          place?.lng != null
            ? Number(place.lng)
            : null,
      }))
    : [];

  /*
  ------------------------------------------------
  COMPLETE PLAN OBJECT
  ------------------------------------------------
  */

  const completePlan = {
    /*
    BASIC PLAN INFORMATION
    */

    mood: planData.mood || "",
    
    memberCount:
      planData.memberCount != null
        ? Number(planData.memberCount)
        : members.length,

    /*
    LOCATION + TRAVEL
    */

    locationMode:
      planData.locationMode || "",

    travelMode:
      planData.travelMode || "",

    currentLocation:
      planData.currentLocation || "",

    /*
    GROUP MEMBERS
    */

    members,

    /*
    PREFERENCES
    */

    budget:
      planData.budget != null
        ? planData.budget
        : "",

    vibes: Array.isArray(planData.vibes)
      ? planData.vibes
      : [],

    /*
    MIDPOINT
    */

    midpoint,

    /*
    RECOMMENDATIONS
    */

    places,

    /*
    PLAN METADATA
    */

    createdAt: serverTimestamp(),

    /*
    USER INFORMATION
    */

    userId: user.uid,

    userEmail: user.email || "",
  };

  /*
  ------------------------------------------------
  SAVE TO FIRESTORE
  ------------------------------------------------
  */

  const plansRef = collection(
    db,
    "users",
    user.uid,
    "plans"
  );

  const documentReference = await addDoc(
    plansRef,
    completePlan
  );

  console.log(
    "Plan successfully saved:",
    documentReference.id
  );

  return {
    id: documentReference.id,
    ...completePlan,
  };
};