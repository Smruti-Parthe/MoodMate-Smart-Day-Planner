/*
 * MoodMate Travel Engine
 *
 * Handles travel calculations for:
 * 1. Private Vehicle
 * 2. Public Transport
 *
 * This version uses OpenStreetMap-compatible services.
 */

/* =========================================================
   DISTANCE CALCULATION
   ========================================================= */

export function calculateDistance(
  lat1,
  lng1,
  lat2,
  lng2
) {
  const earthRadius = 6371;

  const dLat =
    ((lat2 - lat1) * Math.PI) / 180;

  const dLng =
    ((lng2 - lng1) * Math.PI) / 180;

  const a =
    Math.sin(dLat / 2) *
      Math.sin(dLat / 2) +
    Math.cos(
      (lat1 * Math.PI) / 180
    ) *
      Math.cos(
        (lat2 * Math.PI) / 180
      ) *
      Math.sin(dLng / 2) *
      Math.sin(dLng / 2);

  const c =
    2 *
    Math.atan2(
      Math.sqrt(a),
      Math.sqrt(1 - a)
    );

  return earthRadius * c;
}


/* =========================================================
   GEOGRAPHICAL MIDPOINT
   ========================================================= */

export function calculateGeographicalMidpoint(
  locations
) {
  if (
    !locations ||
    locations.length === 0
  ) {
    return null;
  }

  let totalLat = 0;
  let totalLng = 0;

  locations.forEach((location) => {
    totalLat += Number(location.lat);
    totalLng += Number(location.lng);
  });

  return {
    lat:
      totalLat / locations.length,

    lng:
      totalLng / locations.length,
  };
}


/* =========================================================
   PRIVATE VEHICLE MIDPOINT
   =========================================================
   
   For private vehicles we start with the geographical
   midpoint and evaluate how balanced the location is
   for every member.
*/

export function calculatePrivateVehicleMidpoint(
  locations
) {
  if (
    !locations ||
    locations.length === 0
  ) {
    return null;
  }

  const geographicMidpoint =
    calculateGeographicalMidpoint(
      locations
    );

  if (!geographicMidpoint) {
    return null;
  }

  const distances =
    locations.map((member) =>
      calculateDistance(
        member.lat,
        member.lng,
        geographicMidpoint.lat,
        geographicMidpoint.lng
      )
    );

  const totalDistance =
    distances.reduce(
      (sum, distance) =>
        sum + distance,
      0
    );

  const maximumDistance =
    Math.max(...distances);

  return {
    lat: geographicMidpoint.lat,
    lng: geographicMidpoint.lng,

    type: "private",

    totalDistance,
    maximumDistance,

    averageDistance:
      totalDistance /
      locations.length,
  };
}


/* =========================================================
   CREATE PUBLIC TRANSPORT CANDIDATES
   =========================================================
   
   Instead of assuming that the exact geographical midpoint
   is a railway/metro/bus-friendly location, we create
   multiple candidate points.

   Candidates include:
   - geographical midpoint
   - each member location
   - pairwise midpoints
*/

export function createPublicTransportCandidates(
  locations
) {
  if (
    !locations ||
    locations.length === 0
  ) {
    return [];
  }

  const candidates = [];

  /* -----------------------------------------
     Candidate 1: geographical midpoint
  ----------------------------------------- */

  const midpoint =
    calculateGeographicalMidpoint(
      locations
    );

  if (midpoint) {
    candidates.push({
      lat: midpoint.lat,
      lng: midpoint.lng,
      source:
        "Geographical Midpoint",
    });
  }


  /* -----------------------------------------
     Candidate 2: member locations
  ----------------------------------------- */

  locations.forEach(
    (member) => {
      candidates.push({
        lat: Number(member.lat),
        lng: Number(member.lng),

        source:
          `${member.name || "Member"} Area`,
      });
    }
  );


  /* -----------------------------------------
     Candidate 3: pairwise midpoints
  ----------------------------------------- */

  for (
    let i = 0;
    i < locations.length;
    i++
  ) {
    for (
      let j = i + 1;
      j < locations.length;
      j++
    ) {
      const first =
        locations[i];

      const second =
        locations[j];

      candidates.push({
        lat:
          (Number(first.lat) +
            Number(second.lat)) /
          2,

        lng:
          (Number(first.lng) +
            Number(second.lng)) /
          2,

        source:
          "Balanced Meeting Area",
      });
    }
  }

  return candidates;
}


/* =========================================================
   SCORE PUBLIC TRANSPORT CANDIDATE
   =========================================================
   
   Current version uses geographical distance as the
   accessibility proxy.

   Later this function can be connected to an actual
   public transport routing engine to use:
   - train time
   - metro time
   - bus time
   - walking time
   - transfers
*/

export function scorePublicTransportCandidate(
  candidate,
  locations
) {
  if (
    !candidate ||
    !locations ||
    locations.length === 0
  ) {
    return null;
  }

  const distances =
    locations.map((member) =>
      calculateDistance(
        member.lat,
        member.lng,
        candidate.lat,
        candidate.lng
      )
    );

  const totalDistance =
    distances.reduce(
      (sum, distance) =>
        sum + distance,
      0
    );

  const maximumDistance =
    Math.max(...distances);

  const averageDistance =
    totalDistance /
    locations.length;

  /*
   * Fairness:
   *
   * We give extra importance to the member
   * who has to travel the farthest.
   */

  const fairnessPenalty =
    maximumDistance * 1.5;

  const score =
    totalDistance +
    fairnessPenalty;

  return {
    ...candidate,

    totalDistance,
    maximumDistance,
    averageDistance,

    score,
  };
}


/* =========================================================
   PUBLIC TRANSPORT MIDPOINT
   ========================================================= */

export function calculatePublicTransportMidpoint(
  locations
) {
  if (
    !locations ||
    locations.length === 0
  ) {
    return null;
  }

  const candidates =
    createPublicTransportCandidates(
      locations
    );

  if (
    candidates.length === 0
  ) {
    return null;
  }

  const scoredCandidates =
    candidates
      .map((candidate) =>
        scorePublicTransportCandidate(
          candidate,
          locations
        )
      )
      .filter(Boolean);

  if (
    scoredCandidates.length === 0
  ) {
    return null;
  }

  /*
   * Sort from best to worst.
   */

  scoredCandidates.sort(
    (a, b) =>
      a.score - b.score
  );

  const best =
    scoredCandidates[0];

  return {
    lat: best.lat,
    lng: best.lng,

    type: "public",

    source: best.source,

    totalDistance:
      best.totalDistance,

    maximumDistance:
      best.maximumDistance,

    averageDistance:
      best.averageDistance,

    score: best.score,
  };
}


/* =========================================================
   MAIN TRAVEL ENGINE
   =========================================================
   
   This is the function Midpoint.jsx will eventually call.

   travelMode:
   "private"
   OR
   "public"
*/

export function calculateBestMeetingPoint(
  locations,
  travelMode
) {
  if (
    !locations ||
    locations.length === 0
  ) {
    return null;
  }

  if (
    travelMode === "public"
  ) {
    return calculatePublicTransportMidpoint(
      locations
    );
  }

  return calculatePrivateVehicleMidpoint(
    locations
  );
}


/* =========================================================
   FORMAT TRAVEL INFORMATION
   ========================================================= */

export function getTravelModeDescription(
  travelMode
) {
  if (
    travelMode === "public"
  ) {
    return {
      title:
        "Public Transport",

      icon: "🚌",

      description:
        "The meeting point is selected to keep the journey balanced for everyone using public transport.",
    };
  }

  return {
    title:
      "Private Vehicle",

    icon: "🚗",

    description:
      "The meeting point is calculated around the group's geographical center.",
  };
}