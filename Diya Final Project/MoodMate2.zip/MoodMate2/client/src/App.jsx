import { BrowserRouter, Routes, Route } from "react-router-dom";

// ================================
// PAGES
// ================================

import Home from "./pages/Home";
import Login from "./pages/Login";
import Signup from "./pages/Signup";

import Dashboard from "./pages/Dashboard";
import Profile from "./pages/Profile";

import Mood from "./pages/Mood";
import Group from "./pages/Group";
import Preferences from "./pages/Preferences";
import Midpoint from "./pages/Midpoint";

import PublicTransport from "./pages/PublicTransport";
import PrivateTransport from "./pages/PrivateTransport";

import Recommendations from "./pages/Recommendations";

// ================================
// AUTH
// ================================

import ProtectedRoute from "./routes/ProtectedRoute";


function App() {

  return (

    <BrowserRouter>

      <Routes>


        {/* =================================================
            HOME
            PUBLIC
        ================================================= */}

        <Route
          path="/"
          element={<Home />}
        />


        {/* =================================================
            LOGIN
            PUBLIC
        ================================================= */}

        <Route
          path="/login"
          element={<Login />}
        />


        {/* =================================================
            SIGNUP
            PUBLIC
        ================================================= */}

        <Route
          path="/signup"
          element={<Signup />}
        />


        {/* =================================================
            DASHBOARD
            PROTECTED
        ================================================= */}

        <Route
          path="/dashboard"
          element={
            <ProtectedRoute>
              <Dashboard />
            </ProtectedRoute>
          }
        />


        {/* =================================================
            PROFILE
            PROTECTED
        ================================================= */}

        <Route
          path="/profile"
          element={
            <ProtectedRoute>
              <Profile />
            </ProtectedRoute>
          }
        />


        {/* =================================================
            MOODMATE PLAN FLOW
            ALL PROTECTED
        ================================================= */}


        {/* STEP 1
            MOOD
        */}

        <Route
          path="/mood"
          element={
            <ProtectedRoute>
              <Mood />
            </ProtectedRoute>
          }
        />


        {/* STEP 2
            GROUP
        */}

        <Route
          path="/group"
          element={
            <ProtectedRoute>
              <Group />
            </ProtectedRoute>
          }
        />


        {/* STEP 3
            PREFERENCES
        */}

        <Route
          path="/preferences"
          element={
            <ProtectedRoute>
              <Preferences />
            </ProtectedRoute>
          }
        />


        {/* STEP 4
            MIDPOINT
        */}

        <Route
          path="/midpoint"
          element={
            <ProtectedRoute>
              <Midpoint />
            </ProtectedRoute>
          }
        />


        {/* =================================================
            TRANSPORT
            PROTECTED
        ================================================= */}


        {/* PUBLIC TRANSPORT */}

        <Route
          path="/public-transport"
          element={
            <ProtectedRoute>
              <PublicTransport />
            </ProtectedRoute>
          }
        />


        {/* PRIVATE TRANSPORT */}

        <Route
          path="/private-transport"
          element={
            <ProtectedRoute>
              <PrivateTransport />
            </ProtectedRoute>
          }
        />


        {/* =================================================
            RECOMMENDATIONS
            PROTECTED
        ================================================= */}

        <Route
          path="/recommendations"
          element={
            <ProtectedRoute>
              <Recommendations />
            </ProtectedRoute>
          }
        />


        {/* =================================================
            FALLBACK
        ================================================= */}

        <Route
          path="*"
          element={<Home />}
        />

      </Routes>

    </BrowserRouter>
  );
}

export default App;