import { Navigate, useLocation } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

function ProtectedRoute({ children }) {

  const { user, loading } = useAuth();

  const location = useLocation();


  /*
   * =================================================
   * WAIT FOR FIREBASE AUTHENTICATION
   * =================================================
   */

  if (loading) {

    return (
      <div
        style={{
          minHeight: "100vh",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          flexDirection: "column",
          gap: "15px",
          fontFamily: "Arial, sans-serif",
        }}
      >

        <div
          style={{
            fontSize: "40px",
          }}
        >
          ✦
        </div>

        <p>
          Loading MoodMate...
        </p>

      </div>
    );
  }


  /*
   * =================================================
   * USER NOT LOGGED IN
   * =================================================
   *
   * Send them to Login.
   *
   * We also remember the page they were trying
   * to access.
   *
   * Example:
   *
   * User opens /mood
   *
   * ↓
   *
   * Redirect to /login
   *
   * ↓
   *
   * Login
   *
   * ↓
   *
   * Return to /mood
   *
   * =================================================
   */

  if (!user) {

    return (
      <Navigate
        to="/login"
        replace
        state={{
          from: location,
        }}
      />
    );
  }


  /*
   * =================================================
   * USER IS LOGGED IN
   * =================================================
   */

  return children;
}

export default ProtectedRoute;