import React, { useEffect, useRef } from "react";
import Map, {
  Marker,
  NavigationControl,
  Popup,
} from "react-map-gl/maplibre";

import "maplibre-gl/dist/maplibre-gl.css";

/* =========================================================
   MIDPOINT MARKER
========================================================= */

function MidpointMarker() {
  return (
    <div
      style={{
        width: "46px",
        height: "46px",
        borderRadius: "50%",
        background: "#173f35",
        color: "#ffffff",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        fontSize: "24px",
        border: "4px solid white",
        boxShadow: "0 3px 12px rgba(0,0,0,0.25)",
      }}
    >
      ★
    </div>
  );
}

/* =========================================================
   MEMBER MARKER
========================================================= */

function MemberMarker() {
  return (
    <div
      style={{
        width: "40px",
        height: "40px",
        borderRadius: "50%",
        background: "#ffffff",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        fontSize: "22px",
        border: "3px solid #173f35",
        boxShadow: "0 3px 10px rgba(0,0,0,0.2)",
      }}
    >
      📍
    </div>
  );
}

/* =========================================================
   MAIN MOOD MAP
========================================================= */

export default function MoodMap({
  midpoint = {},
  members = [],
}) {
  const mapRef = useRef(null);

  /* =======================================================
     MIDPOINT
  ======================================================= */

  const midpointLat = Number(midpoint?.lat);
  const midpointLng = Number(midpoint?.lng);

  const hasMidpoint =
    Number.isFinite(midpointLat) &&
    Number.isFinite(midpointLng) &&
    midpointLat >= -90 &&
    midpointLat <= 90 &&
    midpointLng >= -180 &&
    midpointLng <= 180;

  /* =======================================================
     VALID MEMBERS
  ======================================================= */

  const validMembers = Array.isArray(members)
    ? members
        .map((member, index) => {
          const lat = Number(member?.lat);
          const lng = Number(member?.lng);

          if (
            !Number.isFinite(lat) ||
            !Number.isFinite(lng) ||
            lat < -90 ||
            lat > 90 ||
            lng < -180 ||
            lng > 180
          ) {
            return null;
          }

          return {
            ...member,
            id:
              member?.id ||
              `member-${index}`,
            name:
              member?.name ||
              `Member ${index + 1}`,
            location:
              member?.location || "",
            lat,
            lng,
          };
        })
        .filter(Boolean)
    : [];

  /* =======================================================
     INITIAL CENTER
  ======================================================= */

  let initialCenter = {
    longitude: 72.8777,
    latitude: 19.076,
  };

  if (hasMidpoint) {
    initialCenter = {
      longitude: midpointLng,
      latitude: midpointLat,
    };
  } else if (validMembers.length > 0) {
    initialCenter = {
      longitude: validMembers[0].lng,
      latitude: validMembers[0].lat,
    };
  }

  /* =======================================================
     ZOOM TO ALL LOCATIONS
  ======================================================= */

  useEffect(() => {
    const map = mapRef.current;

    if (!map) {
      return;
    }

    const allPoints = [];

    if (hasMidpoint) {
      allPoints.push({
        longitude: midpointLng,
        latitude: midpointLat,
      });
    }

    validMembers.forEach((member) => {
      allPoints.push({
        longitude: member.lng,
        latitude: member.lat,
      });
    });

    if (allPoints.length === 0) {
      return;
    }

    const timer = setTimeout(() => {
      try {
        if (allPoints.length === 1) {
          map.flyTo({
            center: [
              allPoints[0].longitude,
              allPoints[0].latitude,
            ],
            zoom: 14,
            duration: 0,
          });

          return;
        }

        let minLng = allPoints[0].longitude;
        let maxLng = allPoints[0].longitude;
        let minLat = allPoints[0].latitude;
        let maxLat = allPoints[0].latitude;

        allPoints.forEach((point) => {
          minLng = Math.min(
            minLng,
            point.longitude
          );

          maxLng = Math.max(
            maxLng,
            point.longitude
          );

          minLat = Math.min(
            minLat,
            point.latitude
          );

          maxLat = Math.max(
            maxLat,
            point.latitude
          );
        });

        map.fitBounds(
          [
            [minLng, minLat],
            [maxLng, maxLat],
          ],
          {
            padding: 80,
            maxZoom: 14,
            duration: 0,
          }
        );
      } catch (error) {
        console.error(
          "Map zoom error:",
          error
        );
      }
    }, 300);

    return () => clearTimeout(timer);
  }, [
    hasMidpoint,
    midpointLat,
    midpointLng,
    validMembers,
  ]);

  /* =======================================================
     FORCE RESIZE
  ======================================================= */

  useEffect(() => {
    const timer1 = setTimeout(() => {
      if (mapRef.current) {
        mapRef.current.resize();
      }
    }, 100);

    const timer2 = setTimeout(() => {
      if (mapRef.current) {
        mapRef.current.resize();
      }
    }, 500);

    const timer3 = setTimeout(() => {
      if (mapRef.current) {
        mapRef.current.resize();
      }
    }, 1000);

    window.addEventListener("resize", () => {
      if (mapRef.current) {
        mapRef.current.resize();
      }
    });

    return () => {
      clearTimeout(timer1);
      clearTimeout(timer2);
      clearTimeout(timer3);
    };
  }, []);

  /* =======================================================
     MAP
  ======================================================= */

  return (
    <div
      style={{
        width: "100%",
        height: "600px",
        minHeight: "600px",
        position: "relative",
        overflow: "hidden",
        borderRadius: "18px",
        background: "#e5e5e5",
      }}
    >
      <Map
        ref={mapRef}
        initialViewState={{
          longitude:
            initialCenter.longitude,
          latitude:
            initialCenter.latitude,
          zoom: 13,
        }}
        style={{
          width: "100%",
          height: "100%",
        }}
        mapStyle="https://basemaps.cartocdn.com/gl/positron-gl-style/style.json"
        mapLib={import("maplibre-gl")}
        reuseMaps={false}
        attributionControl={true}
      >
        {/* =================================================
            NAVIGATION
        ================================================= */}

        <NavigationControl
          position="top-right"
        />

        {/* =================================================
            MIDPOINT
        ================================================= */}

        {hasMidpoint && (
          <>
            <Marker
              longitude={midpointLng}
              latitude={midpointLat}
              anchor="center"
            >
              <MidpointMarker />
            </Marker>

            <Popup
              longitude={midpointLng}
              latitude={midpointLat}
              closeButton={false}
              closeOnClick={false}
              anchor="bottom"
            >
              <div>
                <strong>
                  ★ Group Midpoint
                </strong>

                <br />

                {midpoint?.name ||
                  "Smart Meeting Point"}

                <br />

                <small>
                  {midpointLat.toFixed(5)}
                  {", "}
                  {midpointLng.toFixed(5)}
                </small>
              </div>
            </Popup>
          </>
        )}

        {/* =================================================
            MEMBER MARKERS
        ================================================= */}

        {validMembers.map((member) => (
          <Marker
            key={member.id}
            longitude={member.lng}
            latitude={member.lat}
            anchor="center"
          >
            <MemberMarker />
          </Marker>
        ))}

        {/* =================================================
            CONNECTING LINES
        ================================================= */}

        {hasMidpoint &&
          validMembers.map((member) => {
            const source = `line-${member.id}`;

            return (
              <React.Fragment
                key={source}
              >
                <div
                  style={{
                    position: "absolute",
                    pointerEvents: "none",
                  }}
                />

                <Line
                  mapRef={mapRef}
                  sourceId={source}
                  member={member}
                  midpointLat={midpointLat}
                  midpointLng={midpointLng}
                />
              </React.Fragment>
            );
          })}
      </Map>
    </div>
  );
}

/* =========================================================
   LINE COMPONENT
========================================================= */

function Line({
  mapRef,
  sourceId,
  member,
  midpointLat,
  midpointLng,
}) {
  useEffect(() => {
    const map = mapRef.current;

    if (!map) {
      return;
    }

    const addLine = () => {
      if (!map.isStyleLoaded()) {
        return;
      }

      try {
        if (map.getLayer(sourceId)) {
          map.removeLayer(sourceId);
        }

        if (map.getSource(sourceId)) {
          map.removeSource(sourceId);
        }

        map.addSource(sourceId, {
          type: "geojson",
          data: {
            type: "Feature",
            geometry: {
              type: "LineString",
              coordinates: [
                [
                  member.lng,
                  member.lat,
                ],
                [
                  midpointLng,
                  midpointLat,
                ],
              ],
            },
          },
        });

        map.addLayer({
          id: sourceId,
          type: "line",
          source: sourceId,
          paint: {
            "line-width": 3,
            "line-opacity": 0.7,
            "line-dasharray": [
              2,
              2,
            ],
          },
        });
      } catch (error) {
        console.error(
          "Unable to draw map line:",
          error
        );
      }
    };

    if (map.isStyleLoaded()) {
      addLine();
    } else {
      map.once(
        "load",
        addLine
      );
    }

    return () => {
      try {
        if (map.getLayer(sourceId)) {
          map.removeLayer(sourceId);
        }

        if (map.getSource(sourceId)) {
          map.removeSource(sourceId);
        }
      } catch (error) {
        // Ignore cleanup errors.
      }
    };
  }, [
    mapRef,
    sourceId,
    member,
    midpointLat,
    midpointLng,
  ]);

  return null;
}