import React from "react";
import { MapContainer, TileLayer } from "react-leaflet";
import "leaflet/dist/leaflet.css";

export default function TestMap() {
  return (
    <div
      style={{
        width: "100%",
        height: "600px",
        minHeight: "600px",
        border: "3px solid red",
        position: "relative",
      }}
    >
      <MapContainer
        center={[19.076, 72.8777]}
        zoom={12}
        scrollWheelZoom={true}
        style={{
          width: "100%",
          height: "100%",
          minHeight: "600px",
        }}
      >
        <TileLayer
          attribution="&copy; OpenStreetMap contributors"
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />
      </MapContainer>
    </div>
  );
}