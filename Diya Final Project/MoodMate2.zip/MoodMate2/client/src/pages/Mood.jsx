import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import "./Mood.css";

const moods = [
  { emoji: "😊", name: "Happy", text: "I want to have a good time" },
  { emoji: "😌", name: "Relaxed", text: "I want to chill and unwind" },
  { emoji: "⚡", name: "Energetic", text: "I want something exciting" },
  { emoji: "😔", name: "Low", text: "I need something comforting" },
  { emoji: "❤️", name: "Romantic", text: "I want a romantic experience" },
  { emoji: "🤩", name: "Adventurous", text: "I want to try something new" },
];

export default function Mood() {
  const [selectedMood, setSelectedMood] = useState("");
  const navigate = useNavigate();

  const handleContinue = () => {
    if (!selectedMood) return;

   navigate("/group", {
  state: { mood: selectedMood },
});
  };

  return (
    <div className="mood-page">
      <div className="mood-container">
        <button className="back-btn" onClick={() => navigate("/")}>
          ← Back
        </button>

        <div className="mood-header">
          <span className="small-label">STEP 1 OF 3</span>
          <h1>How are you feeling?</h1>
          <p>
            Tell MoodMate your mood and we'll find experiences
            that match it.
          </p>
        </div>

        <div className="mood-grid">
          {moods.map((mood) => (
            <button
              key={mood.name}
              className={`mood-card ${
                selectedMood === mood.name ? "selected" : ""
              }`}
              onClick={() => setSelectedMood(mood.name)}
            >
              <span className="mood-emoji">{mood.emoji}</span>

              <div>
                <h3>{mood.name}</h3>
                <p>{mood.text}</p>
              </div>

              <span className="check">
                {selectedMood === mood.name ? "✓" : ""}
              </span>
            </button>
          ))}
        </div>

        <button
          className="continue-btn"
          disabled={!selectedMood}
          onClick={handleContinue}
        >
          Continue →
        </button>
      </div>
    </div>
  );
}