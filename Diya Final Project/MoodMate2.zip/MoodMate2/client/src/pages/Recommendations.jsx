import React, { useEffect, useState } from "react";
import {
  useLocation,
  useNavigate,
} from "react-router-dom";

import { useAuth } from "../context/AuthContext";
import { savePlan } from "../services/planService";

import "./Recommendations.css";

/*
=========================================================
MOOD MAPPING
=========================================================
*/

const moodMapping = {
  Happy: [
    "cafe",
    "restaurant",
    "mall",
    "cinema",
    "ice cream",
  ],

  Chill: [
    "cafe",
    "park",
    "bookstore",
    "tea house",
  ],

  Romantic: [
    "rooftop restaurant",
    "garden",
    "beach",
    "cafe",
  ],

  Relax: [
    "park",
    "temple",
    "lake",
    "nature",
  ],

  Adventure: [
    "escape room",
    "adventure park",
    "trekking",
    "gaming zone",
  ],

  Party: [
    "club",
    "lounge",
    "pub",
    "restaurant",
  ],

  Sad: [
    "ice cream",
    "park",
    "temple",
    "quiet cafe",
  ],
};

/*
=========================================================
VIBE MAPPING
=========================================================
*/

const vibeMapping = {
  Cafés: [
    "cafe",
  ],

  Food: [
    "restaurant",
  ],

  Movies: [
    "cinema",
    "movie theater",
  ],

  Outdoors: [
    "park",
    "garden",
    "nature",
  ],

  Games: [
    "bowling",
    "gaming",
    "game center",
  ],

  Creative: [
    "art gallery",
    "museum",
    "art center",
  ],

  Music: [
    "music venue",
    "live music",
  ],

  Shopping: [
    "shopping mall",
    "shopping center",
  ],
};

/*
=========================================================
ITINERARY MAPPING
=========================================================
*/

const itineraryMapping = {
  cafe: [
    "dessert",
    "park",
    "bookstore",
    "shopping",
  ],

  restaurant: [
    "dessert",
    "movie theater",
    "mall",
    "cafe",
  ],

  cinema: [
    "restaurant",
    "dessert",
    "gaming zone",
  ],

  "movie theater": [
    "restaurant",
    "dessert",
    "gaming zone",
  ],

  mall: [
    "restaurant",
    "gaming zone",
    "movie theater",
    "cafe",
  ],

  "shopping mall": [
    "restaurant",
    "gaming zone",
    "movie theater",
    "cafe",
  ],

  "shopping center": [
    "restaurant",
    "cafe",
    "dessert",
  ],

  park: [
    "cafe",
    "ice cream",
    "lake",
  ],

  temple: [
    "park",
    "cafe",
    "lake",
  ],

  lake: [
    "cafe",
    "park",
    "dessert",
  ],

  beach: [
    "cafe",
    "dessert",
    "shopping",
  ],

  "escape room": [
    "restaurant",
    "gaming zone",
    "dessert",
  ],

  "adventure park": [
    "restaurant",
    "cafe",
    "shopping",
  ],

  "gaming zone": [
    "restaurant",
    "movie theater",
    "dessert",
  ],

  gaming: [
    "restaurant",
    "movie theater",
    "dessert",
  ],

  "rooftop restaurant": [
    "dessert",
    "garden",
    "viewpoint",
  ],

  garden: [
    "cafe",
    "dessert",
    "park",
  ],

  trekking: [
    "cafe",
    "restaurant",
    "nature",
  ],

  "ice cream": [
    "park",
    "cafe",
    "shopping",
  ],

  "tea house": [
    "park",
    "bookstore",
    "dessert",
  ],

  "quiet cafe": [
    "park",
    "bookstore",
    "dessert",
  ],

  club: [
    "restaurant",
    "dessert",
    "cafe",
  ],

  lounge: [
    "restaurant",
    "dessert",
    "cafe",
  ],

  pub: [
    "restaurant",
    "dessert",
    "cafe",
  ],

  dessert: [
    "cafe",
    "park",
    "shopping",
  ],

  bookstore: [
    "cafe",
    "park",
    "dessert",
  ],

  shopping: [
    "cafe",
    "restaurant",
    "dessert",
  ],

  nature: [
    "cafe",
    "park",
    "lake",
  ],

  bowling: [
    "restaurant",
    "dessert",
    "movie theater",
  ],

  "game center": [
    "restaurant",
    "dessert",
    "movie theater",
  ],

  "art gallery": [
    "cafe",
    "restaurant",
    "shopping",
  ],

  museum: [
    "cafe",
    "restaurant",
    "park",
  ],

  "art center": [
    "cafe",
    "restaurant",
    "shopping",
  ],

  "music venue": [
    "restaurant",
    "cafe",
    "dessert",
  ],

  "live music": [
    "restaurant",
    "cafe",
    "dessert",
  ],
};

/*
=========================================================
HELPERS
=========================================================
*/

const normalizeCategory = (category = "") => {
  return String(category)
    .toLowerCase()
    .trim()
    .replace(/_/g, " ");
};

const formatCategory = (category = "") => {
  return String(category)
    .replace(/_/g, " ")
    .replace(/\b\w/g, (letter) =>
      letter.toUpperCase()
    );
};

/*
=========================================================
RECOMMENDATIONS COMPONENT
=========================================================
*/

function Recommendations() {
  const navigate = useNavigate();
  const location = useLocation();

  const { user } = useAuth();

  /*
  =========================================================
  DATA FROM PREVIOUS PAGE
  =========================================================
  */

  const data = location.state || {};

  const {
    mood,
    memberCount,
    locationMode,
    travelMode,
    currentLocation,
    members,
    budget,
    vibes,
    midpoint,
  } = data;

  /*
  =========================================================
  STATE
  =========================================================
  */

  const [places, setPlaces] = useState([]);

  const [loading, setLoading] = useState(true);

  const [saving, setSaving] = useState(false);

  const [saved, setSaved] = useState(false);

  const [saveError, setSaveError] = useState("");

  /*
  =========================================================
  ITINERARY STATE
  =========================================================
  */

  const [selectedItineraryPlace, setSelectedItineraryPlace] =
    useState(null);

  /*
  =========================================================
  GET SEARCH LOCATION
  =========================================================
  */

  const getSearchLocation = () => {
    /*
    MIDPOINT FIRST
    */

    if (
      midpoint &&
      midpoint.lat != null &&
      midpoint.lng != null
    ) {
      const lat = Number(midpoint.lat);
      const lng = Number(midpoint.lng);

      if (
        Number.isFinite(lat) &&
        Number.isFinite(lng)
      ) {
        return {
          lat,
          lng,
        };
      }
    }

    /*
    CURRENT LOCATION
    */

    if (
      currentLocation &&
      typeof currentLocation === "string" &&
      currentLocation.includes(",")
    ) {
      const parts = currentLocation
        .split(",")
        .map((value) =>
          Number(value.trim())
        );

      if (
        parts.length === 2 &&
        Number.isFinite(parts[0]) &&
        Number.isFinite(parts[1])
      ) {
        return {
          lat: parts[0],
          lng: parts[1],
        };
      }
    }

    return null;
  };

  /*
  =========================================================
  HAVERSINE DISTANCE
  =========================================================
  */

  const calculateDistance = (
    lat1,
    lon1,
    lat2,
    lon2
  ) => {
    const earthRadius = 6371;

    const dLat =
      ((lat2 - lat1) * Math.PI) / 180;

    const dLon =
      ((lon2 - lon1) * Math.PI) / 180;

    const a =
      Math.sin(dLat / 2) *
        Math.sin(dLat / 2) +
      Math.cos(
        (lat1 * Math.PI) / 180
      ) *
        Math.cos(
          (lat2 * Math.PI) / 180
        ) *
        Math.sin(dLon / 2) *
        Math.sin(dLon / 2);

    const c =
      2 *
      Math.atan2(
        Math.sqrt(a),
        Math.sqrt(1 - a)
      );

    return earthRadius * c;
  };

  /*
  =========================================================
  GET MOOD SEARCH TERMS
  =========================================================
  */

  const getMoodSearchTerms = () => {
    if (!mood) {
      return [];
    }

    if (moodMapping[mood]) {
      return moodMapping[mood];
    }

    const matchingMood =
      Object.keys(moodMapping).find(
        (item) =>
          item.toLowerCase() ===
          String(mood).toLowerCase()
      );

    if (matchingMood) {
      return moodMapping[matchingMood];
    }

    return [];
  };

  /*
  =========================================================
  GET VIBE SEARCH TERMS
  =========================================================
  */

  const getVibeSearchTerms = () => {
    const terms = [];

    if (!Array.isArray(vibes)) {
      return terms;
    }

    vibes.forEach((vibe) => {
      if (vibeMapping[vibe]) {
        terms.push(
          ...vibeMapping[vibe]
        );
      }
    });

    return terms;
  };

  /*
  =========================================================
  GET ALL SEARCH TERMS
  =========================================================
  */

  const getSearchTerms = () => {
    const moodTerms =
      getMoodSearchTerms();

    const vibeTerms =
      getVibeSearchTerms();

    const combined = [
      ...moodTerms,
      ...vibeTerms,
    ];

    const uniqueTerms = [
      ...new Set(
        combined.map((term) =>
          term.toLowerCase()
        )
      ),
    ];

    if (uniqueTerms.length === 0) {
      return [
        "restaurant",
        "cafe",
        "park",
      ];
    }

    return uniqueTerms;
  };

  /*
  =========================================================
  SEARCH PLACES USING OPENSTREETMAP
  =========================================================
  */

  const searchPlaces = async () => {
    setLoading(true);

    const searchLocation =
      getSearchLocation();

    if (!searchLocation) {
      console.error(
        "No midpoint location available."
      );

      setPlaces([]);

      setLoading(false);

      return;
    }

    try {
      const searchTerms =
        getSearchTerms();

      console.log(
        "Selected mood:",
        mood
      );

      console.log(
        "Mood search terms:",
        getMoodSearchTerms()
      );

      console.log(
        "Selected vibes:",
        vibes
      );

      console.log(
        "Final search terms:",
        searchTerms
      );

      const results = [];

      /*
      SEARCH RADIUS
      */

      const radius = 3000;

      const latRadius =
        radius / 111000;

      const lngRadius =
        radius /
        (
          111000 *
          Math.cos(
            (searchLocation.lat *
              Math.PI) /
              180
          )
        );

      const south =
        searchLocation.lat -
        latRadius;

      const north =
        searchLocation.lat +
        latRadius;

      const west =
        searchLocation.lng -
        lngRadius;

      const east =
        searchLocation.lng +
        lngRadius;

      /*
      SEARCH EACH CATEGORY
      */

      for (
        const term of searchTerms
      ) {
        try {
          const url =
            "https://nominatim.openstreetmap.org/search" +
            "?format=json" +
            "&q=" +
            encodeURIComponent(term) +
            "&limit=20" +
            "&bounded=1" +
            "&viewbox=" +
            `${west},${north},${east},${south}`;

          console.log(
            "Searching:",
            term
          );

          const response =
            await fetch(url, {
              headers: {
                Accept:
                  "application/json",
              },
            });

          if (!response.ok) {
            console.error(
              "Nominatim error:",
              response.status
            );

            continue;
          }

          const searchData =
            await response.json();

          if (
            !Array.isArray(
              searchData
            )
          ) {
            continue;
          }

          searchData.forEach(
            (place) => {
              const lat =
                Number(place.lat);

              const lng =
                Number(place.lon);

              if (
                !Number.isFinite(lat) ||
                !Number.isFinite(lng)
              ) {
                return;
              }

              const distance =
                calculateDistance(
                  searchLocation.lat,
                  searchLocation.lng,
                  lat,
                  lng
                );

              if (distance > 3) {
                return;
              }

              const name =
                place.name ||
                place.display_name
                  ?.split(",")[0] ||
                "Recommended Place";

              const address =
                place.display_name ||
                "Location unavailable";

              let category =
                term;

              category =
                category
                  .replace(
                    /_/g,
                    " "
                  )
                  .replace(
                    /\b\w/g,
                    (letter) =>
                      letter.toUpperCase()
                  );

              results.push({
                id:
                  place.place_id ||
                  `${lat}-${lng}-${name}`,

                name,

                address,

                lat,

                lng,

                category,

                searchTerm:
                  term,

                distance:
                  Number(
                    distance.toFixed(2)
                  ),
              });
            }
          );

          /*
          WAIT BETWEEN REQUESTS
          */

          await new Promise(
            (resolve) =>
              setTimeout(
                resolve,
                800
              )
          );

        } catch (error) {
          console.error(
            `Error searching ${term}:`,
            error
          );
        }
      }

      /*
      REMOVE DUPLICATES
      */

      const uniquePlaces = [];

      const seenCoordinates =
        new Set();

      results.forEach(
        (place) => {
          const key =
            `${place.lat.toFixed(
              5
            )}-${place.lng.toFixed(
              5
            )}`;

          if (
            seenCoordinates.has(
              key
            )
          ) {
            return;
          }

          seenCoordinates.add(key);

          uniquePlaces.push(
            place
          );
        }
      );

      /*
      SORT BY DISTANCE
      */

      uniquePlaces.sort(
        (a, b) =>
          a.distance -
          b.distance
      );

      /*
      MAXIMUM 12
      */

      setPlaces(
        uniquePlaces.slice(
          0,
          12
        )
      );

    } catch (error) {
      console.error(
        "Recommendation error:",
        error
      );

      setPlaces([]);
    }

    setLoading(false);
  };

  /*
  =========================================================
  LOAD RECOMMENDATIONS
  =========================================================
  */

  useEffect(() => {
    searchPlaces();

    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  /*
  =========================================================
  CREATE ITINERARY
  =========================================================
  */

  const createItinerary = (place) => {
    if (!place) {
      return;
    }

    /*
    Get category
    */

    const category =
      normalizeCategory(
        place.searchTerm ||
          place.category
      );

    /*
    Find itinerary suggestions
    */

    let suggestions =
      itineraryMapping[
        category
      ];

    /*
    Partial category matching
    */

    if (
      !suggestions ||
      suggestions.length === 0
    ) {
      const matchingKey =
        Object.keys(
          itineraryMapping
        ).find(
          (key) =>
            category.includes(key) ||
            key.includes(category)
        );

      if (matchingKey) {
        suggestions =
          itineraryMapping[
            matchingKey
          ];
      }
    }

    /*
    Generic fallback
    */

    if (
      !suggestions ||
      suggestions.length === 0
    ) {
      suggestions = [
        "cafe",
        "dessert",
        "park",
      ];
    }

    /*
    Create itinerary
    */

    const itinerary = {
      mainPlace: place,

      steps: [
        {
          type: "main",

          category:
            category,

          title:
            place.name,

          address:
            place.address,

          lat:
            place.lat,

          lng:
            place.lng,
        },

        ...suggestions.map(
          (
            suggestion,
            index
          ) => ({
            type:
              "suggestion",

            category:
              suggestion,

            title:
              formatCategory(
                suggestion
              ),

            order:
              index + 2,
          })
        ),
      ],
    };

    /*
    SHOW ITINERARY
    */

    setSelectedItineraryPlace(
      itinerary
    );

    /*
    Scroll to itinerary
    */

    setTimeout(() => {
      document
        .getElementById(
          "suggested-itinerary"
        )
        ?.scrollIntoView({
          behavior: "smooth",
          block: "start",
        });
    }, 100);
  };

  /*
  =========================================================
  CLOSE ITINERARY
  =========================================================
  */

  const closeItinerary = () => {
    setSelectedItineraryPlace(
      null
    );
  };

  /*
  =========================================================
  OPEN DIRECTIONS
  =========================================================
  */

  const openDirections =
    (place) => {
      if (!place) {
        return;
      }

      const url =
        "https://www.google.com/maps/dir/?api=1" +
        `&destination=${place.lat},${place.lng}`;

      window.open(
        url,
        "_blank",
        "noopener,noreferrer"
      );
    };

  /*
  =========================================================
  SAVE COMPLETE PLAN
  =========================================================
  */

  const handleSavePlan =
    async () => {

      if (!user) {
        navigate("/login");
        return;
      }

      if (
        saving ||
        saved
      ) {
        return;
      }

      try {
        setSaving(true);

        setSaveError("");

        const completePlanData = {
          mood:
            mood || "",

          memberCount:
            memberCount != null
              ? Number(memberCount)
              : Array.isArray(
                  members
                )
              ? members.length
              : 0,

          locationMode:
            locationMode || "",

          travelMode:
            travelMode || "",

          currentLocation:
            currentLocation || "",

          members:
            Array.isArray(
              members
            )
              ? members
              : [],

          budget:
            budget != null
              ? budget
              : "",

          vibes:
            Array.isArray(
              vibes
            )
              ? vibes
              : [],

          midpoint:
            midpoint || null,

          places:
            Array.isArray(
              places
            )
              ? places
              : [],

          itinerary:
            selectedItineraryPlace ||
            null,
        };

        console.log(
          "Saving complete plan:",
          completePlanData
        );

        await savePlan(
          user,
          completePlanData
        );

        setSaved(true);

        console.log(
          "Plan saved successfully."
        );

      } catch (error) {
        console.error(
          "Error saving plan:",
          error
        );

        setSaveError(
          error.message ||
            "Unable to save plan."
        );

      } finally {
        setSaving(false);
      }
    };

  /*
  =========================================================
  BACK TO MIDPOINT
  =========================================================
  */

  const handleBack = () => {
    navigate(
      "/midpoint",
      {
        state: data,
      }
    );
  };

  /*
  =========================================================
  LOADING SCREEN
  =========================================================
  */

  if (loading) {
    return (
      <div className="recommendations-page">

        <div className="recommendations-container">

          <div className="recommendations-loading">

            <div className="recommendation-loading-icon">
              ✨
            </div>

            <h2>
              Finding places for your group...
            </h2>

            <p>
              We're looking for places
              around your group's midpoint
              based on your mood and
              preferences.
            </p>

            <div className="recommendation-spinner"></div>

          </div>

        </div>

      </div>
    );
  }

  /*
  =========================================================
  MAIN PAGE
  =========================================================
  */

  return (
    <div className="recommendations-page">

      <div className="recommendations-container">

        {/* BACK */}

        <button
          className="recommendations-back"
          onClick={handleBack}
          type="button"
        >
          ← Back to Midpoint
        </button>

        {/* HEADER */}

        <div className="recommendations-header">

          <span className="recommendations-step">
            YOUR RECOMMENDATIONS
          </span>

          <h1>
            Places you'll love.
          </h1>

          <p>
            We found places around your
            group's midpoint based on
            your mood and preferences.
          </p>

        </div>

        {/* SUMMARY */}

        <div className="recommendation-summary">

          <div className="summary-item">

            <span>
              MOOD
            </span>

            <strong>
              {mood || "Any mood"}
            </strong>

          </div>

          <div className="summary-item">

            <span>
              BUDGET
            </span>

            <strong>
              {budget
                ? `₹${budget} / person`
                : "Flexible"}
            </strong>

          </div>

          <div className="summary-item">

            <span>
              VIBES
            </span>

            <strong>
              {vibes?.length
                ? vibes.join(", ")
                : "Any"}
            </strong>

          </div>

        </div>

        {/* MOOD MATCH */}

        {mood && (
          <div
            style={{
              marginTop: "18px",
              padding: "18px 20px",
              borderRadius: "16px",
              background: "#faf7ff",
              border: "1px solid #e8ddf8",
              display: "flex",
              alignItems: "center",
              gap: "14px",
            }}
          >

            <div
              style={{
                width: "42px",
                height: "42px",
                borderRadius: "12px",
                background: "#eee3ff",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                fontSize: "20px",
                flexShrink: 0,
              }}
            >
              ✦
            </div>

            <div>

              <span
                style={{
                  display: "block",
                  fontSize: "10px",
                  fontWeight: "800",
                  letterSpacing: "1px",
                  color: "#8a55d5",
                  marginBottom: "4px",
                }}
              >
                MOOD MATCHED
              </span>

              <strong
                style={{
                  display: "block",
                  color: "#29252f",
                  fontSize: "15px",
                }}
              >
                Recommendations for your{" "}
                {mood} mood
              </strong>

              <p
                style={{
                  margin: "4px 0 0",
                  fontSize: "12px",
                  color: "#77717d",
                }}
              >
                {getMoodSearchTerms()
                  .slice(0, 4)
                  .join(", ")}
              </p>

            </div>

          </div>
        )}

        {/* MIDPOINT */}

        {midpoint && (
          <div className="recommendation-midpoint">

            <div className="recommendation-midpoint-icon">
              ★
            </div>

            <div>

              <span>
                SMART MIDPOINT
              </span>

              <strong>
                {midpoint.name
                  ? midpoint.name.split(",")[0]
                  : "Your group's sweet spot"}
              </strong>

            </div>

          </div>
        )}

        {/* =================================================
            ITINERARY
        ================================================= */}

        {selectedItineraryPlace && (
          <section
            id="suggested-itinerary"
            style={{
              marginTop: "25px",
              padding: "25px",
              borderRadius: "20px",
              background:
                "linear-gradient(135deg, #faf7ff, #f5f9f6)",
              border: "1px solid #e5dff1",
            }}
          >

            {/* ITINERARY HEADER */}

            <div
              style={{
                display: "flex",
                justifyContent: "space-between",
                alignItems: "flex-start",
                gap: "15px",
                marginBottom: "22px",
              }}
            >

              <div>

                <span
                  style={{
                    display: "block",
                    fontSize: "10px",
                    fontWeight: "800",
                    letterSpacing: "1px",
                    color: "#8a55d5",
                    marginBottom: "6px",
                  }}
                >
                  YOUR SUGGESTED ITINERARY
                </span>

                <h2
                  style={{
                    margin: "0 0 5px",
                    color: "#29252f",
                  }}
                >
                  Plan around{" "}
                  {
                    selectedItineraryPlace
                      .mainPlace
                      .name
                  }
                </h2>

                <p
                  style={{
                    margin: 0,
                    color: "#77717d",
                    fontSize: "13px",
                  }}
                >
                  A simple sequence of places
                  to make your outing more fun.
                </p>

              </div>

              <button
                type="button"
                onClick={closeItinerary}
                style={{
                  border: "none",
                  background: "#ffffff",
                  borderRadius: "10px",
                  width: "34px",
                  height: "34px",
                  cursor: "pointer",
                  fontSize: "18px",
                  color: "#77717d",
                  flexShrink: 0,
                }}
              >
                ×
              </button>

            </div>

            {/* ITINERARY STEPS */}

            <div
              style={{
                display: "flex",
                flexDirection: "column",
                gap: "12px",
              }}
            >

              {selectedItineraryPlace.steps.map(
                (step, index) => (

                  <div
                    key={`${step.category}-${index}`}
                    style={{
                      display: "flex",
                      alignItems: "center",
                      gap: "14px",
                      padding: "15px",
                      borderRadius: "14px",
                      background: "#ffffff",
                      border: "1px solid #ebe7ef",
                    }}
                  >

                    {/* STEP NUMBER */}

                    <div
                      style={{
                        width: "38px",
                        height: "38px",
                        borderRadius: "50%",
                        background:
                          index === 0
                            ? "#8a55d5"
                            : "#eee3ff",
                        color:
                          index === 0
                            ? "#ffffff"
                            : "#8a55d5",
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        fontWeight: "800",
                        fontSize: "13px",
                        flexShrink: 0,
                      }}
                    >
                      {index + 1}
                    </div>

                    {/* STEP CONTENT */}

                    <div
                      style={{
                        flex: 1,
                      }}
                    >

                      <span
                        style={{
                          display: "block",
                          fontSize: "10px",
                          fontWeight: "800",
                          letterSpacing: "0.8px",
                          color: "#8a55d5",
                          marginBottom: "3px",
                        }}
                      >
                        {index === 0
                          ? "START HERE"
                          : `NEXT STOP ${index}`}
                      </span>

                      <strong
                        style={{
                          display: "block",
                          fontSize: "15px",
                          color: "#29252f",
                        }}
                      >
                        {step.title}
                      </strong>

                      {step.address && (
                        <p
                          style={{
                            margin: "4px 0 0",
                            fontSize: "11px",
                            color: "#85808a",
                          }}
                        >
                          📍 {step.address}
                        </p>
                      )}

                    </div>

                    {/* SELECTED LABEL */}

                    {index === 0 && (
                      <span
                        style={{
                          padding: "5px 9px",
                          borderRadius: "8px",
                          background: "#f0e9fb",
                          color: "#8a55d5",
                          fontSize: "10px",
                          fontWeight: "800",
                        }}
                      >
                        SELECTED
                      </span>
                    )}

                  </div>

                )
              )}

            </div>

            <p
              style={{
                margin: "18px 0 0",
                fontSize: "11px",
                color: "#77717d",
              }}
            >
              💡 The additional stops are
              suggested based on your selected
              place category.
            </p>

          </section>
        )}

        {/* =================================================
            RESULTS
        ================================================= */}

        <section className="places-section">

          <div className="places-heading">

            <div>

              <span>
                MATCHED FOR YOU
              </span>

              <h2>
                Recommended places
              </h2>

            </div>

            <div className="results-count">
              {places.length} places
            </div>

          </div>

          {/* NO RESULTS */}

          {places.length === 0 ? (

            <div className="no-results">

              <div>
                🔍
              </div>

              <h2>
                No places found
              </h2>

              <p>
                We couldn't find places
                matching your mood and
                preferences within 3 km
                of the midpoint.
              </p>

              <button
                onClick={() =>
                  navigate(
                    "/preferences",
                    {
                      state: data,
                    }
                  )
                }
                type="button"
              >
                ← Change Preferences
              </button>

            </div>

          ) : (

            <div className="places-grid">

              {places.map(
                (place, index) => (

                  <div
                    className="place-card"
                    key={
                      place.id ||
                      `${place.name}-${index}`
                    }
                  >

                    <div className="place-number">
                      {index + 1}
                    </div>

                    <div className="place-card-content">

                      {/* CATEGORY */}

                      <div className="place-category">
                        {place.category}
                      </div>

                      {/* NAME */}

                      <h3>
                        {place.name}
                      </h3>

                      {/* ADDRESS */}

                      <p className="place-address">
                        📍 {place.address}
                      </p>

                      {/* DISTANCE */}

                      <p
                        style={{
                          margin: "8px 0 0",
                          color: "#8a55d5",
                          fontSize: "11px",
                          fontWeight: "700",
                        }}
                      >
                        📏 {place.distance} km
                        from midpoint
                      </p>

                      {/* ACTIONS */}

                      <div className="place-actions">

                        {/* DIRECTIONS */}

                        <button
                          className="place-direction-btn"
                          onClick={() =>
                            openDirections(
                              place
                            )
                          }
                          type="button"
                        >
                          🧭 Directions
                        </button>

                        {/* CREATE ITINERARY */}

                        <button
                          type="button"
                          className="place-direction-btn"
                          onClick={() =>
                            createItinerary(
                              place
                            )
                          }
                          style={{
                            marginTop: "8px",
                            background: "#8a55d5",
                            color: "#ffffff",
                            border:
                              "1px solid #8a55d5",
                          }}
                        >
                          ✨ Create Itinerary
                        </button>

                      </div>

                    </div>

                  </div>

                )
              )}

            </div>

          )}

        </section>

        {/* =================================================
            SAVE PLAN
        ================================================= */}

        <section
          style={{
            marginTop: "40px",
            padding: "25px",
            borderRadius: "20px",
            background: "#f5f7f3",
            border: "1px solid #e2e5df",
            textAlign: "center",
          }}
        >

          <h3
            style={{
              color: "#174c3b",
              marginBottom: "8px",
            }}
          >
            Save this plan
          </h3>

          <p
            style={{
              color: "#7b8580",
              fontSize: "13px",
              marginBottom: "18px",
            }}
          >
            Save your mood, group,
            preferences, midpoint and
            recommendations to your
            MoodMate history.
          </p>

          {!user ? (

            <button
              className="primary-dashboard-btn"
              onClick={() =>
                navigate(
                  "/login"
                )
              }
              type="button"
            >
              Login to Save Plan
            </button>

          ) : (

            <button
              className="primary-dashboard-btn"
              onClick={
                handleSavePlan
              }
              disabled={
                saving ||
                saved
              }
              type="button"
            >
              {saving
                ? "Saving Plan..."
                : saved
                ? "✓ Plan Saved"
                : "♡ Save This Plan"}
            </button>

          )}

          {saveError && (
            <p
              style={{
                color: "#c0392b",
                fontSize: "13px",
                marginTop: "12px",
              }}
            >
              {saveError}
            </p>
          )}

        </section>

        {/* =================================================
            BOTTOM
        ================================================= */}

        <div className="recommendations-bottom">

          <button
            className="change-preferences-btn"
            onClick={() =>
              navigate(
                "/preferences",
                {
                  state: data,
                }
              )
            }
            type="button"
          >
            ← Change Preferences
          </button>

          <p>
            Recommendations are based on
            your selected mood, budget,
            activities and group's
            midpoint.
          </p>

        </div>

      </div>

    </div>
  );
}

export default Recommendations;