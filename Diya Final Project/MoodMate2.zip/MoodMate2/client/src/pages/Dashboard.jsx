import { useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import "./Dashboard.css";

function Dashboard() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  /*
  =========================================
  LOGOUT
  =========================================
  */

  const handleLogout = async () => {
    try {
      await logout();
      navigate("/login");
    } catch (error) {
      console.error("Logout error:", error);
    }
  };

  /*
  =========================================
  CREATE PLAN
  =========================================
  */

  const handleCreatePlan = () => {
    navigate("/mood");
  };

  /*
  =========================================
  PROFILE
  =========================================
  */

  const handleProfile = () => {
    navigate("/profile");
  };

  return (
    <div className="dashboard-page">

      {/* =========================================
          NAVBAR
      ========================================= */}

      <nav className="dashboard-nav">

        <div
          className="dashboard-logo"
          onClick={() => navigate("/dashboard")}
          style={{ cursor: "pointer" }}
        >
          Mood<span>Mate</span>
        </div>

        <div className="dashboard-user">

          <span>
            Hi, {user?.displayName || "there"} 👋
          </span>

          <button onClick={handleLogout}>
            Logout
          </button>

        </div>

      </nav>


      {/* =========================================
          MAIN CONTENT
      ========================================= */}

      <main className="dashboard-container">

        {/* =========================================
            HEADER
        ========================================= */}

        <div className="dashboard-heading">

          <span className="dashboard-label">
            YOUR MOODMATE
          </span>

          <h1>
            Welcome back,
            <span>
              {" "}
              {user?.displayName || "there"}.
            </span>
          </h1>

          <p>
            What would you like to do today?
          </p>

        </div>


        {/* =========================================
            OPTIONS
        ========================================= */}

        <div className="dashboard-options">


          {/* =========================================
              CREATE PLAN CARD
          ========================================= */}

          <div className="dashboard-option-card">

            <div className="dashboard-option-icon">
              ✦
            </div>

            <span className="dashboard-option-label">
              START SOMETHING NEW
            </span>

            <h2>
              Create a Plan
            </h2>

            <p>
              Tell us your mood, add your friends,
              choose your preferences and find the
              perfect place to meet.
            </p>

            <button
              className="dashboard-primary-btn"
              onClick={handleCreatePlan}
            >
              Create a Plan →
            </button>

          </div>


          {/* =========================================
              PROFILE CARD
          ========================================= */}

          <div className="dashboard-option-card">

            <div className="dashboard-option-icon profile-icon">
              ◉
            </div>

            <span className="dashboard-option-label">
              YOUR ACCOUNT
            </span>

            <h2>
              My Profile
            </h2>

            <p>
              View your profile, previous plans,
              saved meeting locations and
              selected places.
            </p>

            <button
              className="dashboard-secondary-btn"
              onClick={handleProfile}
            >
              View Profile →
            </button>

          </div>

        </div>


        {/* =========================================
            FOOTER MESSAGE
        ========================================= */}

        <div className="dashboard-footer-message">

          <span>
            ✦
          </span>

          <p>
            MoodMate makes planning your next
            hangout simple, personal and fun.
          </p>

        </div>

      </main>

    </div>
  );
}

export default Dashboard;