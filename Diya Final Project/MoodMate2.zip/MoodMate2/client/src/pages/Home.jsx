import { Link } from "react-router-dom";
import "./Home.css";

function Home() {
  return (
    <div className="home">

      {/* =================================================
          NAVBAR
      ================================================= */}

      <nav className="navbar">

        <Link to="/" className="logo">
          Mood<span>Mate</span>
        </Link>

        <div className="nav-links">

          <a href="#how-it-works">
            How it works
          </a>

          <a href="#features">
            Features
          </a>

          <Link
            to="/login"
            className="login-link"
          >
            Login
          </Link>

          <Link
            to="/login"
            className="signup-btn"
          >
            Get Started
          </Link>

        </div>

      </nav>


      {/* =================================================
          HERO
      ================================================= */}

      <main className="hero">

        <div className="hero-content">

          <div className="eyebrow">
            ✦ Your mood. Your people. Your place.
          </div>


          <h1>
            Turn your mood into
            <span> the perfect plan.</span>
          </h1>


          <p>
            MoodMate helps you find the perfect place to
            hang out based on your mood, budget,
            preferences, and everyone's location.
          </p>


          {/* =================================================
              HERO BUTTONS
          ================================================= */}

          <div className="hero-buttons">

            {/* IMPORTANT:
                User must login before accessing Mood
            */}

            <Link
              to="/login"
              className="primary-btn"
            >
              Get Started →
            </Link>


            <a
              href="#how-it-works"
              className="secondary-btn"
            >
              See how it works
            </a>

          </div>


          {/* =================================================
              TRUST ROW
          ================================================= */}

          <div className="trust-row">

            <div>

              <strong>
                ✦ Mood based
              </strong>

              <small>
                Recommendations
              </small>

            </div>


            <div>

              <strong>
                ⌖ Smart midpoint
              </strong>

              <small>
                For your whole group
              </small>

            </div>


            <div>

              <strong>
                ₹ Budget friendly
              </strong>

              <small>
                Options that fit
              </small>

            </div>

          </div>

        </div>


        {/* =================================================
            HERO VISUAL
        ================================================= */}

        <div className="hero-visual">

          <div className="glow"></div>


          <div className="mood-card main-card">

            <div className="card-top">

              <span>
                Your current vibe
              </span>

              <span className="live-dot">
                ●
              </span>

            </div>


            <div className="mood-emoji">
              ☕
            </div>


            <h3>
              Chill & Cozy
            </h3>


            <p>
              Perfect for a relaxed evening with friends.
            </p>


            <div className="mini-location">

              <span>
                ⌖
              </span>


              <div>

                <strong>
                  3 friends nearby
                </strong>

                <small>
                  Finding the perfect midpoint...
                </small>

              </div>

            </div>

          </div>


          <div className="floating-card card-one">
            ✦ <span>Best Match</span>
          </div>


          <div className="floating-card card-two">
            <span>₹₹</span> Within budget
          </div>


          <div className="floating-card card-three">
            ♥ 4.8 <span>rating</span>
          </div>

        </div>

      </main>


      {/* =================================================
          HOW IT WORKS
      ================================================= */}

      <section
        className="how-section"
        id="how-it-works"
      >

        <p className="section-label">
          HOW MOODMATE WORKS
        </p>


        <h2>
          From “what should we do?”
          <br />
          to “let's go!”
        </h2>


        <div className="steps">

          <div className="step">

            <div className="step-number">
              01
            </div>

            <h3>
              Set your mood
            </h3>

            <p>
              Tell us how you're feeling and what kind of
              experience you want.
            </p>

          </div>


          <div className="step">

            <div className="step-number">
              02
            </div>

            <h3>
              Add your friends
            </h3>

            <p>
              Bring everyone's preferences and locations
              into one simple plan.
            </p>

          </div>


          <div className="step">

            <div className="step-number">
              03
            </div>

            <h3>
              Get your spot
            </h3>

            <p>
              We'll find places that match your vibe,
              budget, and group.
            </p>

          </div>

        </div>

      </section>


      {/* =================================================
          CTA
      ================================================= */}

      <section
        className="cta-section"
        id="features"
      >

        <div>

          <p className="section-label">
            READY?
          </p>

          <h2>
            Your next great memory
            <br />
            starts here.
          </h2>

        </div>


        <Link
          to="/login"
          className="primary-btn"
        >
          Get Started →
        </Link>

      </section>


      {/* =================================================
          FOOTER
      ================================================= */}

      <footer>

        <Link
          to="/"
          className="logo"
        >
          Mood<span>Mate</span>
        </Link>

        <p>
          Made for better hangouts.
        </p>

      </footer>

    </div>
  );
}

export default Home;