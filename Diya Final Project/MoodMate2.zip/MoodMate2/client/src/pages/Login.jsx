import { useState } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import "./Login.css";

function Login() {
  const navigate = useNavigate();
  const location = useLocation();
  const { login } = useAuth();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleLogin = async (e) => {
    e.preventDefault();

    setError("");

    if (!email || !password) {
      setError("Please enter your email and password.");
      return;
    }

    try {
      setLoading(true);

      await login(email, password);

      /*
       * After successful login:
       * Go to the page the user originally wanted,
       * otherwise go to Dashboard.
       */
      const from =
  location.state?.from?.pathname || "/mood";

      navigate(from, { replace: true });
    } catch (error) {
      console.error("Login error:", error);

      switch (error.code) {
        case "auth/invalid-credential":
          setError("Invalid email or password.");
          break;

        case "auth/user-not-found":
          setError("No account found with this email.");
          break;

        case "auth/wrong-password":
          setError("Incorrect password.");
          break;

        case "auth/invalid-email":
          setError("Please enter a valid email address.");
          break;

        case "auth/too-many-requests":
          setError(
            "Too many unsuccessful attempts. Please try again later."
          );
          break;

        default:
          setError("Unable to login. Please try again.");
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="login-page">

      {/* NAVBAR */}

      <nav className="login-navbar">

        <Link to="/" className="login-logo">
          Mood<span>Mate</span>
        </Link>

        <div className="login-nav-text">
          Don't have an account?
          <Link to="/signup">
            Sign up
          </Link>
        </div>

      </nav>


      {/* MAIN */}

      <main className="login-main">

        <div className="login-card">

          {/* HEADER */}

          <div className="login-header">

            <div className="login-eyebrow">
              ✦ WELCOME BACK
            </div>

            <h1>
              Let's get
              <span> planning.</span>
            </h1>

            <p>
              Login to continue creating your
              perfect plan with MoodMate.
            </p>

          </div>


          {/* ERROR */}

          {error && (
            <div className="login-error">
              {error}
            </div>
          )}


          {/* FORM */}

          <form
            className="login-form"
            onSubmit={handleLogin}
          >

            <div className="login-field">

              <label htmlFor="email">
                EMAIL
              </label>

              <input
                id="email"
                type="email"
                placeholder="you@example.com"
                value={email}
                onChange={(e) =>
                  setEmail(e.target.value)
                }
                autoComplete="email"
              />

            </div>


            <div className="login-field">

              <label htmlFor="password">
                PASSWORD
              </label>

              <input
                id="password"
                type="password"
                placeholder="Enter your password"
                value={password}
                onChange={(e) =>
                  setPassword(e.target.value)
                }
                autoComplete="current-password"
              />

            </div>


            <button
              type="submit"
              className="login-submit-btn"
              disabled={loading}
            >

              {loading
                ? "Logging in..."
                : "Login →"}

            </button>

          </form>


          {/* SIGNUP */}

          <div className="login-bottom">

            <span>
              New to MoodMate?
            </span>

            <Link to="/signup">
              Create an account
            </Link>

          </div>

        </div>


        {/* DECORATIVE SIDE */}

        <div className="login-decoration">

          <div className="login-glow"></div>

          <div className="login-quote-card">

            <div className="login-quote-icon">
              ✦
            </div>

            <h2>
              Your mood.
              <br />
              Your people.
              <br />
              Your place.
            </h2>

            <p>
              One simple plan for everyone.
            </p>

          </div>

          <div className="login-floating-card login-float-one">
            ✦ Mood matched
          </div>

          <div className="login-floating-card login-float-two">
            ⌖ Smart midpoint
          </div>

          <div className="login-floating-card login-float-three">
            ₹ Within budget
          </div>

        </div>

      </main>

    </div>
  );
}

export default Login;